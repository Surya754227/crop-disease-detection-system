# ============================================
# Crop Disease Detection System Configuration
# ============================================

# Server Configuration
server.port=9090
server.servlet.context-path=/
server.error.include-message=always
server.error.include-stacktrace=on_param

# ============================================
# Database Configuration (H2 - Embedded, No Install Needed)
# ============================================
spring.datasource.url=jdbc:h2:mem:crop_disease_db
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

# JPA/Hibernate Configuration
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=create
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.sql.init.mode=always

# H2 Console (Optional: Access at http://localhost:8080/h2-console)
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console

# ============================================
# Logging Configuration
# ============================================
logging.level.com.cropdetection=DEBUG
logging.level.org.springframework.web=INFO
logging.level.org.hibernate=INFO

# ============================================
# Application-Specific Configuration
# ============================================
# Upload directory for storing uploaded images
app.upload.dir=uploads

# Python AI API URL (Update when Python backend is running)
app.ai.api.url=http://localhost:5000

# ============================================
# Spring Boot Actuator (Optional - for monitoring)
# ============================================
management.endpoints.web.exposure.include=health,info
management.endpoint.health.show-details=always
